/*
 * Copyright 2020 Astera Labs, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. Thsi file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/*
 * @file aries_globals.h
 * @brief Definition of enums and structs globally used by the SDK.
 */

#include "aries_api_types.h"

#ifndef ASTERA_ARIES_SDK_GLOBALS_H
#define ASTERA_ARIES_SDK_GLOBALS_H

///////////////////////////////////////
////////// EEPROM parameters //////////
///////////////////////////////////////

/** EEPROM Page Count */
#define ARIES_EEPROM_PAGE_COUNT 1024
/** EEPROM Page Size */
#define ARIES_EEPROM_PAGE_SIZE  256
/** Max Burst Size */
#define ARIES_MAX_BURST_SIZE    256
/** EEPROM MM block write size */
#define ARIES_EEPROM_BLOCK_WRITE_SIZE 16
/** EEPROM MM block checksum write size */
#define ARIES_EEPROM_BLOCK_CHECKSUM_WRITE_SIZE 8

/** Total EEPROM size (in bytes) */
#define ARIES_EEPROM_NUM_BYTES 262144

/** Value indicating FW was loaded properly */
#define ARIES_LOAD_CODE 0xe

/** Time delay between checking MM status of EEPROM write (microseconds) */
// #define ARIES_MM_STATUS_TIME 1000
#define ARIES_MM_STATUS_TIME 5000
/** Time between resetting command byte in EEPROM read */
#define ARIES_I2C_MASTER_CMD_RST 2000
// #define ARIES_I2C_MASTER_CMD_RST 1000
/** Delay after writing data in rewrite and re-verify step */
#define ARIES_I2C_MASTER_WRITE_DELAY 50000
// #define ARIES_I2C_MASTER_WRITE_DELAY 5000
/** Time delay after sending EEPROM read command to Main Micro */
#define ARIES_MM_READ_CMD_WAIT 10000
/** Time allocated to calculate checksum (secs) */
#define ARIES_MM_CALC_CHECKSUM_WAIT 6
/** Time allocated to calculate checksum (micro secs) */
#define ARIES_MM_CALC_CHECKSUM_TRY_TIME 10000

/** Num banks per EEPROM (num slaves) */
#define ARIES_EEPROM_NUM_BANKS 4
/** EEPROM Bank Size (num slaves) */
#define ARIES_EEPROM_BANK_SIZE 0x10000

/** Main Micro code for checksum computation */
#define ARIES_MM_EEPROM_CHECKSUM_CODE 16

/** Main Micro code for checksum computation (partial) */
#define ARIES_MM_EEPROM_CHECKSUM_PARTIAL_CODE 17

/** Num EEPROM CRC blocks */
#define ARIES_EEPROM_MAX_NUM_CRC_BLOCKS 10

//////////////////////////////////////
////////// Delay parameters //////////
//////////////////////////////////////

/** Wait time after completing an EEPROM block write-thru */
#define ARIES_DATA_BLOCK_PROGRAM_TIME_USEC  10000
/** Wait time after setting manual training */
#define ARIES_MAN_TRAIN_WAIT_SEC           0.01

//////////////////////////////////////
////////// Memory parameters //////////
//////////////////////////////////////

/** Main Micro num of print class enables in logger module */
#define ARIES_MM_PRINT_INFO_NUM_PRINT_CLASS_EN 8

/** Main Micro print buffer size */
#define ARIES_MM_PRINT_INFO_NUM_PRINT_BUFFER_SIZE 512

/** Path Micro num of print class enables in logger module */
#define ARIES_PM_PRINT_INFO_NUM_PRINT_CLASS_EN 16

/** Path Micro print buffer size */
#define ARIES_PM_PRINT_INFO_NUM_PRINT_BUFFER_SIZE 256

/////////////////////////////////////////////////////////////////////////
////////// Pma slice register addresses for cmd, addr and data //////////
/////////////////////////////////////////////////////////////////////////

/** Num. sides for PMA */
#define ARIES_NUM_SIDES 2

/** Num. quad slices per slice */
#define ARIES_NUM_QUAD_SLICES 4

/** PMA 0 identifier */
#define ARIES_RD_PID_IND_PMA0 6

/** PMA 1 identifier */
#define ARIES_RD_PID_IND_PMA1 7

///////////////////////////////////////////////////////////
//////////// Temparature measurement constants ////////////
///////////////////////////////////////////////////////////

/** Num of readings to take at each PMA */
#define ARIES_TEMP_NUM_READINGS  16

/** Temperature to offset result by */
#define ARIES_TEMPERATURE_OFFSET  25

/** Aries Pma temperature measurement slope val */
#define ARIES_TEMP_SLOPE ((310-560)/(105-25))

/** Aries Pma temperature offset (min) */
#define ARIES_TEMP_OFFSET_MIN 560

/** Aries Pma temperature offset (max) */
#define ARIES_TEMP_OFFSET_MAX 625

/** Aries max temp ADC code CSR */
#define ARIES_MAX_TEMP_ADC_CSR 0x424
#define ARIES_ALL_TIME_MAX_TEMP_ADC_CSR 0x424

/** Aries current max temp ADC code CSR */
#define ARIES_CURRENT_MAX_TEMP_ADC_CSR 0x428

/** Aries current average temp ADC code CSR */
#define ARIES_CURRENT_TEMP_ADC_CSR 0x42c
#define ARIES_CURRENT_AVG_TEMP_ADC_CSR 0x42c

/** Aries temp calibration uncertainity offset */
#define ARIES_TEMP_CALIBRATION_OFFSET 3

//////////////////////////////////////////////////////////
///////////////////// Miscellaneous //////////////////////
//////////////////////////////////////////////////////////

/** CRC8 polynomial used in PEC computation */
#define ARIES_CRC8_POLYNOMIAL 0x107

/** Num DPLL frequency readings to capture */
#define ARIES_NUM_DPLL_FREQ_READINGS 7

/** Num DPLL frequency reading tries */
#define ARIES_NUM_DPLL_FREQ_READING_TRIES 5


#endif /* ASTERA_ARIES_SDK_GLOBALS_H */
