/*
 * Copyright 2020 Astera Labs, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. Thsi file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/*
 * @file astera_log.h
 * @brief Logging module for Aries.
 */

#ifndef ASTERA_LOG_H
#define ASTERA_LOG_H

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>

#define LOG_VERSION "0.1.0"

typedef void (*log_LockFn)(void *udata, int lock);

enum {
    AL_LOG_TRACE,
    AL_LOG_DEBUG,
    AL_LOG_INFO,
    AL_LOG_WARN,
    AL_LOG_ERROR,
    AL_LOG_FATAL
};

#define ASTERA_TRACE(...) al_log_log(AL_LOG_TRACE, __FILE__, __LINE__, __VA_ARGS__)
#define ASTERA_DEBUG(...) al_log_log(AL_LOG_DEBUG, __FILE__, __LINE__, __VA_ARGS__)
#define ASTERA_INFO(...)  al_log_log(AL_LOG_INFO,  __FILE__, __LINE__, __VA_ARGS__)
#define ASTERA_WARN(...)  al_log_log(AL_LOG_WARN,  __FILE__, __LINE__, __VA_ARGS__)
#define ASTERA_ERROR(...) al_log_log(AL_LOG_ERROR, __FILE__, __LINE__, __VA_ARGS__)
#define ASTERA_FATAL(...) al_log_log(AL_LOG_FATAL, __FILE__, __LINE__, __VA_ARGS__)

void al_log_set_udata(void *udata);
void al_log_set_lock(log_LockFn fn);
void al_log_set_fp(FILE *fp);
void al_log_set_level(int level);
void al_log_set_quiet(int enable);

void al_log_log(int level, const char *file, int line, const char *fmt, ...);

#endif
