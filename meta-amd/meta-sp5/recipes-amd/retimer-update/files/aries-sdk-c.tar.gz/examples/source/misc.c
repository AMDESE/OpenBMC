#include "../include/misc.h"
#include <linux/i2c-dev.h>

AriesErrorType ariesRunArp0x55(
        int handle)
{
    int rc;
    uint8_t dataByte[1];
    uint8_t rdataBytes[19];

    dataByte[0] = 0xc9;
    rc = asteraI2CWriteBlockData(handle, 0x2, 1, dataByte);
    CHECK_SUCCESS(rc);

    dataByte[0] = 0xc0;
    rc = asteraI2CWriteBlockData(handle, 0x1, 1, dataByte);
    CHECK_SUCCESS(rc);

    // This read will get first device repsonse in ARP mode
    rc = asteraI2CReadBlockData(handle, 0x3, 19, rdataBytes);
    if (rc != 19)
    {
        return ARIES_I2C_BLOCK_READ_FAILURE;
    }

    // Program slave address of device to 0x55
    uint8_t dataBytes[19] = {17, 1, 9, 29, 250, 0, 1, 0, 21, 0, 0, 0, 0, 0, 0,
        0, 1, 170, 125};

    rc = asteraI2CWriteBlockData(handle, 0x4, 19, dataBytes);
    CHECK_SUCCESS(rc);

    return ARIES_SUCCESS;
}


AriesErrorType ariesRunArp(
        int handle,
        uint8_t new7bitSmbusAddr)
{
    int rc;
    uint8_t dataByte[1];
    uint8_t rdataBytes[19];


    dataByte[0] = 0xc9;
    rc = asteraI2CWriteBlockData(handle, 0x2, 1, dataByte);
    CHECK_SUCCESS(rc);

    dataByte[0] = 0xc0;
    rc = asteraI2CWriteBlockData(handle, 0x1, 1, dataByte);
    CHECK_SUCCESS(rc);

    // This read will get first device repsonse in ARP mode
    rc = asteraI2CReadBlockData(handle, 0x3, 19, rdataBytes);
    if (rc != 19)
    {
        return ARIES_I2C_BLOCK_READ_FAILURE;
    }

    // The PEC byte is calculated from 20 bytes of data including the ARP slave
    // address byte (0x61<<1 = 0xc2), the command code (0x4), and the remainder
    // of the Assign Address command.
    uint8_t new8bitSmbusAddr = new7bitSmbusAddr << 1;
    uint8_t pec_data[21] = {0xc2, 4, 17, 1, 9, 29, 250, 0, 1, 0, 21, 0, 0,
        0, 0, 0, 0, 0, 1, 0, 0}; // last byte is new 8-bit SMBus address
    pec_data[19] = new8bitSmbusAddr;
    uint8_t crc = getPecByte(pec_data, 21);

    // Program slave address of device to 0x55
    uint8_t dataBytes[19];
    uint8_t i;
    for (i = 0; i < 18; i++)
    {
        dataBytes[i] = pec_data[i+2];
    }
    dataBytes[18] = crc; // PEC byte

    rc = asteraI2CWriteBlockData(handle, 0x4, 19, dataBytes);
    CHECK_SUCCESS(rc);

    return ARIES_SUCCESS;
}


uint8_t crc8_slow(
        uint8_t crc,
        uint8_t *data,
        int len)
{
    if (data == NULL)
    {
        return 0;
    }
    crc = ~crc & 0xff;
    while (len--)
    {
        crc ^= *data++;
        int k;
        for (k = 0; k < 8; k++)
        {
            crc = crc & 1 ? (crc >> 1) ^ 0xb2 : crc >> 1;
        }
    }
    return crc ^ 0xff;
}

uint8_t getBitInByte(
        uint8_t byte,
        uint8_t index)
{
    return ((byte >> index) & 1);
}

uint8_t getPecByte(
        uint8_t* polynomial,
        uint8_t length)
{
    uint8_t crc;
    int byteIndex;
    int bitIndex;

    // Shift polynomial by 1 so that it is 8 bit
    // Take this extra bit into account later
    uint8_t poly = 0x107 >> 1;
    crc = polynomial[0];

    for(byteIndex=1; byteIndex<length; byteIndex++)
    {
        uint8_t nextByte = polynomial[byteIndex];
        for(bitIndex=7; bitIndex>=0; bitIndex--)
        {
            // Check if MSB in CRC is 1
            if(crc & 0x80)
            {
                // Perform subtraction of first 8 bits
                crc = (crc ^ poly) << 1;
                // Add final bit of mod2 subtraction and place in pos 0 of CRC
                crc = crc + (getBitInByte(nextByte, bitIndex) ^ 1);
            }
            else
            {
                // Shift out 0
                crc = crc << 1;
                // Shift in next bit
                crc = crc + getBitInByte(nextByte, bitIndex);
            }
        }
    }
    return crc;
}


AriesErrorType svbSwitchRead(
        int handle,
        int reg)
{
    uint8_t cmd;
    uint8_t values[1];
    int rc;

    if (reg == 1)
    {
        cmd = 0x1;
    }
    else if (reg ==2)
    {
        cmd  = 0x2;
    }
    else {
        return ARIES_INVALID_ARGUMENT;
    }

    rc = asteraI2CWriteBlockData(handle, cmd, 0, values);
    CHECK_SUCCESS(rc);

    return ARIES_SUCCESS;
}


AriesErrorType calcImageChecksum(
        uint8_t* image,
        int startAddr,
        int numBytes,
        uint8_t* checkSum)
{
    uint8_t runningChecksum = 0;

    // Check for invalid values of numBytes and startAddr
    // 2Mbit = 262144 bytes
    if ((numBytes <= 0) || (startAddr < 0) || (startAddr >= 262144) ||
      ((startAddr+numBytes-1) >= 262144))
    {
        return ARIES_INVALID_ARGUMENT;
    }

    // Calculate the expected checksum
    int i;
    for (i = startAddr; i < (startAddr + numBytes); i++)
    {
        runningChecksum = (runningChecksum + image[i]) % 256;
    }
    *checkSum = runningChecksum;

    return ARIES_SUCCESS;
}


// Check connection health
AriesErrorType checkConnectionHealth(
        AriesDeviceType* device,
        uint8_t slaveAddress)
{
    AriesErrorType rc;
    int arpHandle;
    uint8_t dataByte[1];
    device->arpEnable = false;
    rc = ariesReadByteData(device->i2cDriver, ARIES_CODE_LOAD_REG, dataByte);
    if(rc != ARIES_SUCCESS)
    {
        // Failure to read code, run ARP
        ASTERA_WARN("Failed to read code_load, Run ARP");
        // Perform Address Resolution Protocol (ARP) to set the Aries slave
        // address. Aries slave will respond to 0x61 during ARP.
        // NOTE: In most cases, Aries firmware will disable ARP and the Retimer
        // will take on a fixed SMBus address: 0x20, 0x21, ..., 0x27.
        arpHandle = openI2CConnection(device->i2cBus, 0x61);
        rc = ariesRunArp(arpHandle, slaveAddress); // Run ARP, user addr
        if (rc != ARIES_SUCCESS)
        {
            ASTERA_ERROR("ARP connection unsuccessful");
            return -1;
        }

        // Update Aries SMbus driver
        device->i2cDriver->handle = openI2CConnection(device->i2cBus, slaveAddress);
        device->arpEnable = true;
        rc = ariesReadByteData(device->i2cDriver, ARIES_CODE_LOAD_REG,
            dataByte);
        if(rc != ARIES_SUCCESS)
        {
            ASTERA_ERROR("Failed to read code_load after ARP");
            return -1;
        }
    }
    return ARIES_SUCCESS;
}
