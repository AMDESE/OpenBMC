/*
 * Copyright 2020 Astera Labs, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license"file accompanying this file. Thsi file is distributed
 * on an "AS IS"BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/*
 * @file parse_ihx_file.c
 * @brief Implementation of function to parse ihx file and convert to byte
 * array
 */

#include "../include/parse_ihx_file.h"

/* parses a line of intel hex code, stores the data in bytes[] */
/* and the beginning address in addr, and returns a 1 if the */
/* line was valid, or a 0 if an error occured.  The variable */
/* num gets the number of bytes that were stored into bytes[] */
int parseIhxLine(
        char* line,
        uint8_t* bytes,
        int* addr,
        int* num,
        int* code)
{
    int sum, len, cksum;
    char *ptr;

    *num = 0;
    // First char
    if (line[0] != ':')
    {
        return 0;
    }

    if (strlen(line) < 11)
    {
        return 0;
    }
    ptr = line+1;

    if (!sscanf(ptr, "%02x", &len))
    {
        return 0;
    }
    ptr += 2;

    if ( strlen(line) < (11 + (len * 2)) )
    {
        return 0;
    }
    if (!sscanf(ptr, "%04x", addr))
    {
        return 0;
    }
    ptr += 4;

    if (!sscanf(ptr, "%02x", code))
    {
        return 0;
    }
    ptr += 2;
    sum = (len & 255) + ((*addr >> 8) & 255) + (*addr & 255) + (*code & 255);
    int val;
    int status;
    while(*num != len)
    {
        status = sscanf(ptr, "%02x", &val);
        bytes[*num] = (uint8_t) val;
        if(!status)
        {
            return 0;
        }
        ptr += 2;
        sum += bytes[*num] & 255;
        (*num)++;
        if (*num >= 256)
        {
            return 0;
        }
    }
    if (!sscanf(ptr, "%02x", &cksum))
    {
        return 0;
    }
    if ( ((sum & 255) + (cksum & 255)) & 255 )
    {
        return 0; /* checksum error */
    }
    return 1;
}

/* loads an intel hex file into the global memory[] array */
/* filename is a string of the file to be opened */
void loadIhxFile(
        char* filename,
        uint8_t* mem)
{
    char line[1000];
    FILE *fin;
    int addr;
    int n;
    int status;
    uint8_t bytes[256];
    int byte;
    int total=0;
    int lineno=1;
    int minAddr=0xffff;
    int maxAddr=0;

    // Check if file is valid
    if (strlen(filename) == 0)
    {
        printf("   Can't load a file without the filename.");
        printf("  '?' for help\n");
        return;
    }
    fin = fopen(filename, "r");
    if (fin == NULL)
    {
        printf("   Can't open file '%s' for reading.\n", filename);
        return;
    }

    int indx = 0;
    while (!feof(fin) && !ferror(fin))
    {
        line[0] = '\0';
        fgets(line, 1000, fin);
        if (line[strlen(line)-1] == '\n')
        {
            line[strlen(line)-1] = '\0';
        }
        if (line[strlen(line)-1] == '\r')
        {
            line[strlen(line)-1] = '\0';
        }

        if (parseIhxLine(line, bytes, &addr, &n, &status))
        {
            if (status == 0)
            {  /* data */
                for(byte=0; byte<=(n-1); byte++)
                {
                    mem[indx] = bytes[byte] & 0xff;
                    total++;
                    if (addr < minAddr) minAddr = addr;
                    if (addr > maxAddr) maxAddr = addr;
                    addr++;
                    indx++;
                }
            }
            if (status == 1)
            {  /* end of file */
                fclose(fin);
                return;
            }
        }
        else
        {
            printf("   Error: '%s', line: %d\n", filename, lineno);
        }
        lineno++;
    }
}
