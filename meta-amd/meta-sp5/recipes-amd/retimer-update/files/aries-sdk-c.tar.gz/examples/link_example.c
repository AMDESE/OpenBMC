/*
 * Copyright 2020 Astera Labs, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. Thsi file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/*
 * @file link_example.c
 * @brief Example application showing a recommended procedure for:
 *        - Setting up Aries Retimer data structures to store status and
 *          diagnostics information on a per-Link basis.
 *        - Continuous monitoring of key status parameters (e.g. Link state,
 *          junction temperature, eye height/width monitors, etc.).
 *        - Error-scenario handling for cases where continuous monitoring has
 *          determined the state is unexpected and additional debug information
 *          needs to be gathered.
 */

#include <unistd.h>
#include <stdio.h>

#include "include/aspeed.h"
#include "include/misc.h"
#include "include/links.h"
#include "../include/aries_api.h"

int main(int argc, char* argv[])
{
    // -------------------------------------------------------------------------
    // SETUP
    // -------------------------------------------------------------------------
    // This portion of the example shows how to set up data structures for
    // accessing and monitoring Aries Retimres.

    // Create I2C Driver for Aries Retimer
    AriesDeviceType* ariesDevice;
    AriesI2CDriverType* i2cDriver;
    AriesErrorType rc;
    int i2cBus = 1;
    int ariesSlaveAddress = 0x20;
    int ariesHandle;

    // Enable SDK-level debug prints
    al_log_set_level(1); // ASTERA_INFO type statements (or higher)

    // Open connection to Aries Retimer
    ariesHandle = openI2CConnection(i2cBus, ariesSlaveAddress);

    // Initialize I2C Driver for SDK transactions
    i2cDriver = (AriesI2CDriverType*) malloc(sizeof(AriesI2CDriverType));
    i2cDriver->handle = ariesHandle;
    i2cDriver->pecEnable = ARIES_I2C_PEC_DISABLE;
    i2cDriver->i2cFormat = ARIES_I2C_FORMAT_ASTERA;
    // Flag to indicate lock has not been initialized. Call ariesInitDevice()
    // later to initiatlize.
    i2cDriver->lockInit = 0;

    // Set up Aries device struct
    ariesDevice = (AriesDeviceType*) malloc(sizeof(AriesDeviceType));
    ariesDevice->i2cDriver = i2cDriver;
    ariesDevice->partNumber = ARIES_PTX16;
    rc = ariesInitDevice(ariesDevice);
    CHECK_SUCCESS(rc);

    // Read an Aries register (Global Param Reg 0)
    // This is an indication if I2C access is working as expected
    // Return error if read fails
    uint8_t dataBytes[4];
    rc = ariesReadBlockData(i2cDriver, 0, 4, dataBytes);
    if (rc != ARIES_SUCCESS)
    {
        ASTERA_ERROR("Failed to read gbl_param_reg0");
        return rc;
    }
    int glb_param_reg0 = (dataBytes[3]<<24) + (dataBytes[2] <<16)
        + (dataBytes[1]<<8) + dataBytes[0];
    ASTERA_INFO("glb_param_reg0 = 0x%08x", glb_param_reg0);

    // Print FW version
    uint8_t fwVersionMajor = ariesDevice->fwVersion.major;
    uint8_t fwVersionMinor = ariesDevice->fwVersion.minor;
    uint16_t fwVersionBld = ariesDevice->fwVersion.build;
    ASTERA_INFO("FW Version: %d.%d.%d", fwVersionMajor, fwVersionMinor,
        fwVersionBld);

    // Set temperature thresholds
    ariesDevice->tempAlertThreshC = 110.0; // Trigger alert when Temp > 110C
    ariesDevice->tempWarnThreshC = 100.0; // Trigger warn when Temp > 100C
    ariesDevice->minLinkFoMAlert = 0x30; // Trigger warn when link FoM < 0x55

    // Set DPLL frequency thresholds
    ariesDevice->minDPLLFreqAlert = 2*1024;
    ariesDevice->maxDPLLFreqAlert = 14*1024;

    // Configure Link structs
    // NOTE: In this case, we have one Link structure for one Link; however,
    // a system may have N Links supported by M Retimers (N>M), and therefore
    // multiple link objects/structs may be used to keep track of the Links'
    // status.
    AriesLinkType link[1];
    link[0].device = ariesDevice;
    link[0].config.linkId = 0;
    link[0].config.partNumber = ARIES_PTX16;
    link[0].config.maxWidth = 16;
    link[0].config.startLane = 0;

    // -------------------------------------------------------------------------
    // CONTINUOUS MONITORING
    // -------------------------------------------------------------------------
    // This portion of the example shows how Aries Links can be monitored
    // periodically during regular system health checking.
    int run = 1;
    // Dump Link Logs if user passes in argument with value 1
    bool dumpLogs = false;
    if (argc >= 2)
    {
        if (argv[1][0] == '1')
        {
            dumpLogs = true;
        }
    }
    while(run)
    {
        // Get current link state for link[0]
         rc = ariesCheckLinkHealth(&link[0]);
         CHECK_SUCCESS(rc);

        // ---------------------------------------------------------------------
        // ERROR-SCENARIO HANDLING
        // ---------------------------------------------------------------------
        // Check if Link is in an unexpected state, and if not, capture
        // additional debug information.
        // The expected Retimer state during PCIe L0 is the "Forwarding" state.
        if(link[0].state.linkOkay == false || dumpLogs == true)
        {
            ASTERA_ERROR("Unexpected link state: %d", link[0].state.state);
            ASTERA_ERROR("Now capturing link stats and logs");

            // Capture detailed state information
            // This function prints detailed state information to a file
            rc = ariesPrintLinkDetailedState(&link[0]);
            CHECK_SUCCESS(rc);

            // This function prints Aries LTSSM logs to a file
            rc = ariesPrintMicroLogs(&link[0]);
            CHECK_SUCCESS(rc);

            // In this example, the continuous monitoring section exits when the
            // Link state is unexpected.
            break;
        }

        // Wait 5 seconds before reading state again (this up to the user)
        sleep(5);
    }

    // Close I2C connections which were opened earlier
    closeI2CConnection(ariesHandle);

    // Return success
    return 0;
}
