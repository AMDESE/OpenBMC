/*
 * Copyright 2020 Astera Labs, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. Thsi file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/*
 * @file link_example_with_recovery.c
 * @brief Example application showing a recommended procedure for:
 *        - Setting up Aries Retimer data structures to store status and
 *          diagnostics information on a per-Link basis.
 *        - Checking the SMBus communications integrity on an Aries Retimer,
 *          including the integrity of the firmware image.
 *        - Check Firmware load status.
 *        - Check EEPROM image checksum versus expected checksum.
 *        - Reprogram the EEPROM (thru the Retimer) if the integrity check
 *          fails or if an update is pending.
 *        - Continuous monitoring of key status parameters (e.g. Link state,
 *          junction temperature, eye height/width monitors, etc.).
 *        - Error-scenario handling for cases where continuous monitoring has
 *          determined the state is unexpected and additional debug information
 *          needs to be gathered.
 */

#include <unistd.h>
#include <stdio.h>

#include "include/aspeed.h"
#include "include/misc.h"
#include "include/links.h"
#include "include/eeprom.h"
#include "include/parse_ihx_file.h"
#include "../include/aries_api.h"

int main(void)
{
    // -------------------------------------------------------------------------
    // SETUP
    // -------------------------------------------------------------------------
    // This portion of the example shows how to set up data structures for
    // accessing and monitoring Aries Retimers.

    // Desired Retimer I2C Master port frequency
    int ariesI2CMasterFreqHz = 400000;

    // Desired Retimer SMBus (7-bit) address in case ARP needs to be run.
    // Note: Make sure this will not conflict with other device slave addresses.
    uint8_t ariesArpAddr7bit = 0x24;

    // Firmware images
    // In this example, consider two images:
    //   aries_fw_current.ihx -- This is the "current" FW expected on the system
    //   aries_fw_new.ihx     -- This is the "new" FW needing to be loaded
    char fwImageFileCurrent[50] = "pt416_x16_reversed_cc_v1_2_0.ihx";
    char fwImageFileNew[50] = "pt416_x16_reversed_cc_v1_3_0.ihx";
    bool fwUpdatePending = false;
    bool writeToEndOfImage = false;
    bool forceSafeModeEepromWrite = true; // 'safe mode' performs only I2C
                                          // writes to avoid potential bus
                                          // conflicts associated with two-part
                                          // I2C read transactions.
    // Convert each image into a byte array. This example converts .ihx file to
    // to byte array. Max number of bytes is 2Mbit = 262,144 bytes
    int numBytes = 262144;
    uint8_t imageCurrent[numBytes];
    uint8_t imageNew[numBytes];
    // Source code for loadIhxFile in examples/source/parse_ihx_file.c
    loadIhxFile(fwImageFileCurrent, imageCurrent);
    if (fwUpdatePending == true)
    {
      loadIhxFile(fwImageFileNew, imageNew);
    }

    // Create I2C Driver for an instance of the Aries Retimer
    AriesDeviceType* ariesDevice;
    AriesI2CDriverType* i2cDriver;
    AriesErrorType rc;
    int i2cBus = 1;
    int ariesSlaveAddress = 0x20;
    int ariesHandle;
    int arpHandle;

    // Enable SDK-level debug prints
    al_log_set_level(2); // ASTERA_WARN type statements (or higher)

    // Open connection to Aries Retimer
    ariesHandle = openI2CConnection(i2cBus, ariesSlaveAddress);
    i2cDriver = (AriesI2CDriverType*) malloc(sizeof(AriesI2CDriverType));
    i2cDriver->handle = ariesHandle;
    i2cDriver->pecEnable = ARIES_I2C_PEC_DISABLE;
    i2cDriver->i2cFormat = ARIES_I2C_FORMAT_ASTERA;
    // Flag to indicate lock has not been initialized. Call ariesInitDevice()
    // later to initiatlize.
    i2cDriver->lockInit = 0;

    // Initialize Aries device structure
    ariesDevice = (AriesDeviceType*) malloc(sizeof(AriesDeviceType));
    ariesDevice->i2cDriver = i2cDriver;
    ariesDevice->partNumber = ARIES_PTX16;
    ariesDevice->i2cBus = i2cBus;

    // Check Connection and Init device
    // If the connection is not good, the checkConnectionHealth() API will
    // enable ARP and update the i2cDriver with the new address.
    rc = checkConnectionHealth(ariesDevice, ariesArpAddr7bit);
    if(rc != ARIES_SUCCESS)
    {
        ASTERA_FATAL("Connection check failed");
        return -1;
    }

    // ariesInitDevice() checks for the Main Micro heartbeat before reading the
    // FW version. Incase the heartbeat is not up, it sets the firmware version
    // to 0.0.0. It does not set any other device parameters
    rc = ariesInitDevice(ariesDevice);
    if(rc != ARIES_SUCCESS)
    {
        ASTERA_ERROR("Init device failed");
        return -1;
    }

    // Check FW load status (register address: ARIES_CODE_LOAD_REG)
    // You should read back a value since the read was already confirmed in
    // the checkConnectionHealth() API
    bool rewriteEepromImage = false;
    uint8_t dataBytes[4];
    rc = ariesReadBlockData(ariesDevice->i2cDriver, ARIES_CODE_LOAD_REG, 1,
      dataBytes);
    CHECK_SUCCESS(rc);

    if(ariesDevice->arpEnable)
    {
        rewriteEepromImage = true;
    }
    else if (dataBytes[0] < 0xe)
    {
        ASTERA_WARN("Code load status indicates incomplete/unsuccessful load");
        rewriteEepromImage = true;
    }

    // Read the current EEPROM checksum
    // This is OPTIONAL. The Retimer boot loader will check the CRC for each
    // data block in the EEPROM. Computing a checksum at runtime with the
    // example code below will ensure that the EEPROM contents are consistent
    // with the expected EEPROM contents.
    /*
    rc = ariesI2CMasterSetFrequency(ariesDevice->i2cDriver, ariesI2CMasterFreqHz);
    CHECK_SUCCESS(rc);
    uint8_t eepromChecksum = 0;
    rc = ariesEepromCalcChecksum(ariesDevice, 0, 1024, &eepromChecksum);
    if (rc != ARIES_SUCCESS)
    {
        ASTERA_ERROR("Failed to read and calculated EEPROM checksum");
        return -1;
    }
    // Calculate the expected checksum
    uint8_t eepromChecksumExpected;
    rc = calcImageChecksum(imageCurrent, 0, 1024, &eepromChecksumExpected);
    CHECK_SUCCESS(rc);

    if (eepromChecksum != eepromChecksumExpected)
    {
        ASTERA_WARN("EEPROM read checksum does not match expected checksum");
        rewriteEepromImage = true;
    }
    */

    // Check if a "legacy mode" FW update is required, either because one
    // is pending or current FW is suspected of corruption.
    if ((rewriteEepromImage == true) ||
        ((forceSafeModeEepromWrite == true) && (fwUpdatePending == true)))
    {
        // Rewrite the latest (current) EEPROM image using the "legacy" mode
        // since FW is not running to assist the write-thru (legacyMode=true).
        // Function in examples/source/eeprom.c
        rc = ariesWriteEEPROMImageSafe(ariesDevice, imageCurrent, numBytes,
          ariesI2CMasterFreqHz, writeToEndOfImage);
        if (rc != ARIES_SUCCESS)
        {
            ASTERA_ERROR("Failed to write current image to the EEPROM");
            return -1;
        }
        // Verify image that was programmed
        rc = ariesVerifyEEPROMImage(ariesDevice, imageCurrent, numBytes, true);
        CHECK_SUCCESS(rc);
        ASTERA_INFO("EEPROM write and verification succeeded");
    }
    else if (fwUpdatePending == true)
    {
        // A firmware update is pending. Write to the EEPROM thru the Retimer
        // using the faster main-micro-assist mode (legacyMode=false)
        // Function in examples/source/eeprom.c
        rc = writeEEPROMImageNoArp(ariesDevice, imageNew, numBytes, false,
          ariesI2CMasterFreqHz);
        if (rc != ARIES_SUCCESS)
        {
            ASTERA_ERROR("Failed to write new image to the EEPROM");
            return -1;
        }
        // Verify image that was programmed
        rc = ariesVerifyEEPROMImage(ariesDevice, imageNew, numBytes, false);
        CHECK_SUCCESS(rc);
        ASTERA_INFO("EEPROM write and verification succeeded");
    }

    if(rewriteEepromImage || fwUpdatePending)
    {
        ASTERA_WARN("EEPROM was recently updated");
        ASTERA_WARN("Need to reboot system for new firmware to take effect");
    }

    // Print FW version
    uint8_t fwVersionMajor = ariesDevice->fwVersion.major;
    uint8_t fwVersionMinor = ariesDevice->fwVersion.minor;
    uint16_t fwVersionBld = ariesDevice->fwVersion.build;
    ASTERA_INFO("FW Version: %d.%d.%d", fwVersionMajor, fwVersionMinor,
        fwVersionBld);

    // Set temperature thresholds
    ariesDevice->tempAlertThreshC = 110.0; // Trigger alert when Temp > 110C
    ariesDevice->tempWarnThreshC = 100.0; // Trigger warn when Temp > 100C
    ariesDevice->minLinkFoMAlert = 0x30; // Trigger warn when link FoM < 0x55

    // Configure Link structs
    // NOTE: In this case, we have one Link structure for one Link; however,
    // a system may have N Links supported by M Retimers (N>M), and therefore
    // multiple link objects/structs may be used to keep track of the Links'
    // status.
    AriesLinkType link[1];
    link[0].device = ariesDevice;
    link[0].config.linkId = 0;
    link[0].config.partNumber = ariesDevice->partNumber;
    link[0].config.maxWidth = 16;
    link[0].config.startLane = 0;

    // -------------------------------------------------------------------------
    // CONTINUOUS MONITORING
    // -------------------------------------------------------------------------
    // This portion of the example shows how Aries Links can be monitored
    // periodically during regular system health checking.
    int run = 1;
    while(run)
    {
        // Get current link state for link[0]
         rc = ariesGetLinkState(&link[0]);
         CHECK_SUCCESS(rc);

        // All-in-one Link health check. Checks junction temperature, Link LTSSM
        // state, per-Lane eye height/width, etc.
        // If the linkstate is not good, exit.
        rc = ariesCheckLinkHealth(&link[0]);
        if(link[0].state.linkOkay == false)
        {
            ASTERA_ERROR("Link state not okay");
            break;
        }

        // ---------------------------------------------------------------------
        // ERROR-SCENARIO HANDLING
        // ---------------------------------------------------------------------
        // Check if Link is in an unexpected state, and if not, capture
        // additional debug information.
        // The expected Retimer state during PCIe L0 is the "Forwarding" state.
        if (link[0].state.state != ARIES_STATE_FWD)
        {
            ASTERA_ERROR("Unexpected link state: %d", link[0].state.state);
            ASTERA_ERROR("Now capturing link stats and logs");

            // Capture detailed state information
            // This function prints detailed state information to a file
            rc = ariesPrintLinkDetailedState(&link[0]);
            CHECK_SUCCESS(rc);

            // This function prints Aries LTSSM logs to a file
            rc = ariesPrintMicroLogs(&link[0]);
            CHECK_SUCCESS(rc);

            // In this example, the continuous monitoring section exits when the
            // Link state is unexpected.
            break;
        }

        // Wait 5 seconds before reading state again (this up to the user)
        sleep(5);
    }

    // Close I2C connections which were opened earlier
    closeI2CConnection(ariesHandle);

    // Return success
    return 0;
}
