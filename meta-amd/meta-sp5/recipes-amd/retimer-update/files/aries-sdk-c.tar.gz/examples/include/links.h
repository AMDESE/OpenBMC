/*
 * Copyright 2020 Astera Labs, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license"file accompanying this file. Thsi file is distributed
 * on an "AS IS"BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/*
 * @file links.h
 * @brief Helper functions used by link status examples
 */

#ifndef ASTERA_ARIES_SDK_LINKS_H_
#define ASTERA_ARIES_SDK_LINKS_H_

#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "../../include/aries_api.h"
#include "../../include/aries_error.h"

// Function to print a log entry to file
void writeLogToFile(
        FILE* fp,
        AriesLTSSMEntryType* entry);

// Function to iterate over logger and print entry
AriesErrorType ariesPrintMicroLogs(
        AriesLinkType* link);

// Capture the detailed link state and print it to file
AriesErrorType ariesPrintLinkDetailedState(
        AriesLinkType* link);

// Print the micro logger entries
AriesErrorType ariesPrintLog(
        AriesLinkType* link,
        AriesLTSSMLoggerEnumType log,
        FILE* fp);

#endif // ASTERA_ARIES_SDK_LINKS_H_
