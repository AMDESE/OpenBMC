/*
 * Copyright 2020 Astera Labs, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license"file accompanying this file. Thsi file is distributed
 * on an "AS IS"BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/*
 * @file parse_ihx_file.h
 * @brief Implementation of function to parse ihx file and convert to byte
 * array
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>

/* this loads an intel hex file into the mem[] array */
void loadIhxFile(
        char *filename,
        uint8_t *mem);

/* this is used by loadFile to get each line of intex hex */
int parseIhxLine(
        char *theline,
        uint8_t bytes[],
        int *addr,
        int *num,
        int *code);
