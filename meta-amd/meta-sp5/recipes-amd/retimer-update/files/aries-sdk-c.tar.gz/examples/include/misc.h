/*
 * Copyright 2020 Astera Labs, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license"file accompanying this file. Thsi file is distributed
 * on an "AS IS"BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/*
 * @file misc.h
 * @brief Implementation of helper functions used by the examples
 */

#ifndef ASTERA_ARIES_EX_MISC_H_
#define ASTERA_ARIES_EX_MISC_H_

#include <stdint.h>
#include <stdio.h>

#include "../../include/astera_log.h"
#include "../../include/aries_i2c.h"
#include "../../include/aries_api_types.h"
#include "../../include/aries_error.h"
#include "aspeed.h"

// Way to connect driver to either Aries or EEPROM
AriesErrorType svbSwitchRead(
        int handle,
        int reg);

// Set Slave address to 0x55
AriesErrorType ariesRunArp0x55(
        int handle);

// Set Slave address to user-specified value: new7bitSmbusAddr
AriesErrorType ariesRunArp(
        int handle,
        uint8_t new7bitSmbusAddr);

// crc8_slow() is a bit-wise implementation of crc8() that does not need a hash
// table in memory.
uint8_t crc8_slow(
        uint8_t crc,
        uint8_t *data,
        int len);

// Calculate the checksum of a FW image
AriesErrorType calcImageChecksum(
        uint8_t* image,
        int startAddr,
        int numBytes,
        uint8_t* checkSum);

uint8_t getPecByte(
        uint8_t* polynomial,
        uint8_t length);

uint8_t getBitInByte(
        uint8_t byte,
        uint8_t index);

// Check connection health
AriesErrorType checkConnectionHealth(
        AriesDeviceType* device,
        uint8_t slaveAddress);

#endif // ASTERA_ARIES_EX_MISC_H_
