/*
 * Copyright 2020 Astera Labs, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. Thsi file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/*
 * @file astera_test.c
 * @brief Example application targeting basic testing of the Aries SDK. This is
 *        recommended for:
 *        - Setting up Aries device and driver data structures
 *        - Reading genreal purpose registers
 *        - Getting the FW version
 */

#include <unistd.h>

#include "../include/aries_api.h"
#include "include/aspeed.h"
#include "include/misc.h"

int main()
{
    AriesDeviceType* ariesDevice;
    AriesI2CDriverType* i2cDriver;
    AriesErrorType rc;

    int i2cBus = 1;
    int ariesSlave = 0x20;
    int ariesHandle;

    // Connect to retimer
    ariesHandle = openI2CConnection(i2cBus, ariesSlave);
    i2cDriver = (AriesI2CDriverType*) malloc(sizeof(AriesI2CDriverType));
    i2cDriver->handle = ariesHandle;
    i2cDriver->slaveAddr = ariesSlave;
    i2cDriver->pecEnable = ARIES_I2C_PEC_DISABLE;
    i2cDriver->i2cFormat = ARIES_I2C_FORMAT_ASTERA;
    // Flag to indicate lock has not been initialized. Call ariesInitDevice()
    // later to initiatlize.
    i2cDriver->lockInit = 0;

    ariesDevice = (AriesDeviceType*) malloc(sizeof(AriesDeviceType));
    ariesDevice->i2cDriver = i2cDriver;
    ariesDevice->i2cBus = i2cBus;

    rc = ariesInitDevice(ariesDevice);
    CHECK_SUCCESS(rc);

    ariesDevice->partNumber = ARIES_PTX16;

    // Print SDK version
    ASTERA_INFO("SDK Version: %s", ariesGetSDKVersion());

    // Print FW version
    ASTERA_INFO("FW Version: %d.%d.%d", ariesDevice->fwVersion.major,
        ariesDevice->fwVersion.minor, ariesDevice->fwVersion.build);

    uint8_t dataBytes[4];
    rc = ariesReadBlockData(i2cDriver, 0, 4, dataBytes);
    if (rc != ARIES_SUCCESS)
    {
        ASTERA_ERROR("Failed to read gbl_param_reg0");
        return rc;
    }
    int glb_param_reg0 = (dataBytes[3]<<24) + (dataBytes[2] <<16)
        + (dataBytes[1]<<8) + dataBytes[0];
    ASTERA_INFO("glb_param_reg0 = 0x%08x", glb_param_reg0);

    /*Read Temperature*/
    rc = ariesGetJunctionTemp(ariesDevice);
    CHECK_SUCCESS(rc);
    ASTERA_INFO("Temp Seen: %.2f C", ariesDevice->maxTempC);

    closeI2CConnection(ariesHandle);
    return 0;
}
