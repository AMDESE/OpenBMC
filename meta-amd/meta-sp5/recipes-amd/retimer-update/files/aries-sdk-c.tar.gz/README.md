# aries-sdk-c

## Introduction
This repository contains a C-language Software Developers' Kit (C-SDK) for the [Aries PCIe Retimer](https://www.asteralabs.com/products-services). The documentation for this C-SDK can be found in html/index.html. This is the home page for the repository. To view the list of files, click on the "Files" tab and "File List" under it. This lists the .c and .h files in the C-SDK. Clicking on any of the files shows the list of functions, defines, structs, and enums with a brief description.

## Integration
To integrate the Aries C-SDK into a larger Baseboard Management Controller (BMC) software, refer to guidance in the following sections.

### Build Considerations
The Aries C-SDK source code files (.c) are in the **source** directory, and the include files (.h) are in the **include** directory. The example applications in the **examples** directory make use of the APIs defined in **source** and **include**. The Makefile at the root of this repository shows how these example applications can be built to include the application code and C-SDK code.

### Starting Point: A Generic BMC Software
This integration example assumes the existing BMC software structure consists of three basic sections:
1. **Setup**: Various data structures are set up (initialized) in this portion. These data structures are used during the second and third sections of the software program.
2. **Continuous Monitoring**: Various portions of the system (e.g. a server) are monitored periodically to ensure they are operating in their expected states.
3. **Error-Scenario Handling**: In the event an error scenario is encountered during the continuous monitoring phase, this portion of the software is designed to handle those scenarios.

Here is a pseudocode example of an existing BMC software, *before* the Aries C-SDK is integrated:
```c
int rc; // generic function return code
int main(void)
{
    // -------------------------------------------------------------------------
    // SETUP PHASE
    // -------------------------------------------------------------------------
    // Create PCIe Link objects for the five PCIe Links in the system.
    pcieLinkType pcieLink[PCIE_NUM_LINKS];

    // Link 0
    pcieLink[0].width = 16; // PCIe Link width: x16
    pcieLink[0].maxSpeed = 4; // PCIe Link speed: Gen4 (16 GT/s)
    pcieLink[0].okay = true; // Link is okay
    // Link 1
    pcieLink[1].width = 4; // PCIe Link width: x4
    pcieLink[1].maxSpeed = 4; // PCIe Link speed: Gen4 (16 GT/s)
    pcieLink[1].okay = true; // Link is okay
    // Link 2
    pcieLink[2].width = 4; // PCIe Link width: x4
    pcieLink[2].maxSpeed = 4; // PCIe Link speed: Gen4 (16 GT/s)
    pcieLink[2].okay = true; // Link is okay
    // Link 3
    pcieLink[3].width = 4; // PCIe Link width: x4
    pcieLink[3].maxSpeed = 4; // PCIe Link speed: Gen4 (16 GT/s)
    pcieLink[3].okay = true; // Link is okay
    // Link 4
    pcieLink[4].width = 4; // PCIe Link width: x4
    pcieLink[4].maxSpeed = 4; // PCIe Link speed: Gen4 (16 GT/s)
    pcieLink[4].okay = true; // Link is okay

    // Create per-Link Aries Retimer objects
    // Assume one Aries Retimer is used to support Link[0] (x16), and one Aries Retimer is used to support Link[4:1] (x4x4x4x4).

    // -------------------------------------------------------------------------
    // CONTINUOUS MONITORING PHASE
    // -------------------------------------------------------------------------
    bool everythingIsOkay = true;
    while(everythingIsOkay)
    {
        // Check PCIe Link status
        for (int linkNum = 0; linkNum < PCIE_NUM_LINKS; linkNum += 1)
        {
            // Check Link health for Link number linkNum
            rc = pcieLinkCheckHealth(&pcieLink[linkNum]);
            if (pcieLink[linkNum].okay == false)
            {
                everythingIsOkay = false;
            }
        }
    }

    // -------------------------------------------------------------------------
    // ERROR-SCENARIO HANDLING PHASE
    // -------------------------------------------------------------------------
    for (int linkNum = 0; linkNum < PCIE_NUM_LINKS; linkNum += 1)
    {
        // Collect debug info for problematic Links
        if (pcieLink[linkNum].okay == false)
        {
            pcieLinkGetDebugTrace(pcieLink[linkNum]);
        }
    }
}
```

### Integrating Aries C-SDK into the Generic BMC Software
The pseudocode below shows how the Aries C-SDK can be integrated into the generic BMC software presented in the previous section.

```c
int rc; // generic function return code
int main(void)
{
    // -------------------------------------------------------------------------
    // SETUP PHASE
    // -------------------------------------------------------------------------
    // Create Aries Link objects for each Link supported by an Aries Retimer
    AriesLinkType ariesLink[PCIE_NUM_RETIMER_LINKS];

    // Create PCIe Link objects for the five PCIe Links in the system.
    pcieLinkType pcieLink[PCIE_NUM_LINKS];

    // Link 0
    pcieLink[0].width = 16; // PCIe Link width: x16
    pcieLink[0].maxSpeed = 4; // PCIe Link speed: Gen4 (16 GT/s)
    pcieLink[0].retimer = true;
    pcieLink[0].retimerLinkObj = &ariesLink[0];
    pcieLink[0].okay = true; // Link is okay
    // Link 1
    pcieLink[1].width = 4; // PCIe Link width: x4
    pcieLink[1].maxSpeed = 4; // PCIe Link speed: Gen4 (16 GT/s)
    pcieLink[1].retimer = true;
    pcieLink[1].retimerLinkObj = &ariesLink[1];
    pcieLink[1].okay = true; // Link is okay
    // Link 2
    pcieLink[2].width = 4; // PCIe Link width: x4
    pcieLink[2].maxSpeed = 4; // PCIe Link speed: Gen4 (16 GT/s)
    pcieLink[2].retimer = true;
    pcieLink[2].retimerLinkObj = &ariesLink[2];
    pcieLink[2].okay = true; // Link is okay
    // Link 3
    pcieLink[3].width = 4; // PCIe Link width: x4
    pcieLink[3].maxSpeed = 4; // PCIe Link speed: Gen4 (16 GT/s)
    pcieLink[3].retimer = true;
    pcieLink[3].retimerLinkObj = &ariesLink[3];
    pcieLink[3].okay = true; // Link is okay
    // Link 4
    pcieLink[4].width = 4; // PCIe Link width: x4
    pcieLink[4].maxSpeed = 4; // PCIe Link speed: Gen4 (16 GT/s)
    pcieLink[4].retimer = true;
    pcieLink[4].retimerLinkObj = &ariesLink[4];
    pcieLink[4].okay = true; // Link is okay

    // -------------------------------------------------------------------------
    // CONTINUOUS MONITORING PHASE
    // -------------------------------------------------------------------------
    bool everythingIsOkay = true;
    while(everythingIsOkay)
    {
        // Check PCIe Link status
        for (int linkNum = 0; linkNum < PCIE_NUM_LINKS; linkNum += 1)
        {
            // Check Link health for Link number linkNum
            rc = pcieLinkCheckHealth(&pcieLink[linkNum]);
            if (pcieLink[linkNum].okay == false)
            {
                everythingIsOkay = false;
            }

            // All-in-one Link health check. Checks junction temperature, Link LTSSM
            // state, per-Lane eye height/width, etc.
            // Note: This can be integrated into the pcieLinkCheckHealth() method.
            rc = ariesCheckLinkHealth(&pcieLink[linkNum].retimerLinkObj);
            if (pcieLink[linkNum].retimerLinkObj.linkOkay == false)
            {
                everythingIsOkay = false;
            }
        }
    }

    // -------------------------------------------------------------------------
    // ERROR-SCENARIO HANDLING PHASE
    // -------------------------------------------------------------------------
    for (int linkNum = 0; linkNum < PCIE_NUM_LINKS; linkNum += 1)
    {
        // Collect debug info for problematic Links
        if (pcieLink[linkNum].okay == false)
        {
            pcieLinkGetDebugTrace(pcieLink[linkNum]);
        }

        // Collect Retimer debug info (detailed link state, electrical parameters, LTSSM history log, etc.)
        // Note: This can be integrated into the pcieLinkGetDebugTrace() method.
        if (pcieLink[linkNum].retimerLinkObj.linkOkay == false)
        {
            // Capture detailed state information
            // This function prints detailed state information to a file
            rc = ariesPrintLinkDetailedState(&pcieLink[linkNum].retimerLinkObj);

            // This function prints Aries LTSSM logs to a file
            rc = ariesPrintMicroLogs(&pcieLink[linkNum].retimerLinkObj);
        }
    }
}
```

## Post Processing Scripts for Link Statistics and Logging

We provide python scripts to help display the stats and link logs in a better and more readable format.

Requirements: Python 3.0+

### Script to Print Link Stats

**print_link_state.py** is a post processing script which could be used to present the link stats in a tabular form. The SDK generates detailed log files, named **link_state_detailed_log_0.py** (where 0 is the link number), which contains a Python dictionary containing the all the statistics for a given link. This script helps present the data in a more readable format.

To run this post processing script, place the SDK generated log files in the **link_state_logs** folder and run the python script. The output is printed to stdout and to a log file. The **--folder** parameter is optional. Here is an example to run the command:

```bash
python ./print_link_state --folder link_state_logs
```

where **link_state_logs** is the directory containing the C-SDK generated log files.

Note: The generated log file contains all the stats the SDK has to offer. This script also prints out all the log stats, but could be customized to only print the link stats you would like to monitor. For reference to generating this log file, please refer to examples/link_example.c and examples/source/links.c

We have included the **link_state_logs** directory in the SDK as an example and reference for you to run the script.

### Script to Print Link Micro Logs

**print_link_logs.py** is a post processing script to print the Main Micro and Path Micro logs generated by the C-SDK. The logger module in the SDK generates a list of format IDs and data values which are then mapped to a corresponding log message through a post-processing Python script. The C-SDK log module is FW independent, but the post-processing Python script requires references to the format ID dictionaries generated along with a firmware release. The C-SDK output is in form of a Python dictionary and one log file is generated per link. In the example we provide, this file is named as **ltssm_log_X.py** (where X is the link id). Per link, the log will contain Main and Path Micro logs.

**ALMainFmtIDDict.py** and **ALPathFmtIDDict.py** contain the format id to log message translations. These files are released along with a new firmware, and are only valid with that firmware. If the firmware version of ALMainFmtIDDict.py and ALPathFmtIDDict.py are different from the SDK generated format id log, the resulting log messages are invalid. Although we do return an error message in such a case, please make sure that the FW version between files are consistent.

To run this post processing script, place the SDK generated log files in the **link_micro_logs** folder and run the python script. The output is printed to stdout and to a log file. The **--folder** parameter is optional. Here is an example to run the command:

```bash
python ./print_link_logs --folder link_micro_logs
```

where **link_micro_logs** is the directory containing the C-SDK generated log files ltssm_log.py, and the firmware dictionaries ALMainFmtIDDict.py and ALPathFmtIDDict.py.

We have included the **link_micro_logs** directory in the SDK as an example and reference for you to run the script.

## Updating the FW on Aries

The Aries SDK suite includes APIs to program the EEPROM on the SVB. The EEPROM programming happens via the Retimer. We provide two routines related to programming the EEPROM:

1. **ariesWriteEEPROMImage()**: API to program the EEPROM.
2. **ariesVerifyEEPROMImage()**: API to verify the programming to the EEPROM after the contents have been written

The input to both the above functions is the contents of the EEPROM specified as a byte array. To generate the byte array, we provide a way to parse a Intel hex file and convert it to a byte array. You could also generate the byte array yourself and include it in the EEPROM write application. Please refer to examples/eeprom_test.c for reference on programming the EEPROM.

We recommend running the verify EEPROM API after programming the EEPROM.

### Rewriting and Re-verifying EEPROM Content on Failure

While verifying the EEPROM programming, if we encounter an error, i.e. the data read from the EEPROM does not match what you expected to write to the EEPROM, we rewrite the expected byte to the EEPROM and re-verify the byte at the same address.

### Updating Firmware on Aries over a Current Invalid Firmware

If the current firmware on Aries is invalid or empty, all register accesses will fail. In such a case, ARP (Address Resolution Protocol) needs to be enabled in order to successfully perform read and write transactions. To support this, we provide an API (writeEEPROMImage()) to write contents to the EEPROM after enabling ARP. This API is in examples/source/eeprom.c.

### Integrating EEPROM Write into C SDK

The pseudocode below shows how to integrate the EEPROM programming in the SDK. Please use examples/eeprom_test.c for reference to programming the EEPROM.

```c
int rc;
AriesI2CDriverType i2cDriver;

int main(void)
{
    // Max num bytes is 2MB, 262144 bytes
    int numBytes = 262144;
    int errorCode;     // return code from API call
    uint8_t image[numBytes];

    // Load fwVersion.ihx
    // This functions converts the intel hex file to a byte array
    // An implementation of this function is in examples/source/parse_ihx_file.c
    loadImage("fwVersion.ihx", image);

    // This functions writes the contents of image to the EEPROM, and verifies
    // contents of EEPROM after write against image. If all good, it returns
    // zero as error code. Else returns a negative error code.
    errorCode = writeEEPROMImage(ariesDevice, image, numBytes);
    if(errorCode != 0)
    {
        printf("ERROR! EEPROM write failed");
    }

    return 0;
}
```

### Programming EEPROM Directly

We also provide routines to program a firmware image to the EEPROM directly. The routines are:

1. **writeEEPROM()**: Write a firmware image to the EEPROM
2. **verifyEEPROM()**: Verify EEPROM contents against an expected firmware image

The arguments to both these functions are - EEPROM slave addresses, BMC handles to these slave addresses, number of bytes of data to write, and the data to be written specified as a byte array. These routines are defined in examples/source/eeprom.c and are not part of the Aries SDK suite. Please refer to examles/eeprom_direct.c for reference on using these routines.

## Asserting and De-asserting PCIE Reset

**ariesSetPcieReset()** is an API in the SDK which can be called to assert and de-assert PCIE reset for a given link. Based on the link id (which is set when initializing the link struct), the API will accordingly set or clear the bit for that link. When calling the API, set 1 to assert and 0 to de-assert. Please give at least 1 ms between asserting and de-asserting reset.

# Examples

## Programming the EEPROM

There are 2 ways to program the EEPROM. One way is to program the EEPROM directly from the BMC, and the other is to program the EEPROM via the Retimer.

### Program the EEPROM Directly

This example application includes APIs to program the EEPROM directly and verify its contents against the expected firmware image. In order to run these APIs, the BMC must have a connection directly to the EEPROM slaves. You can find this example at examples/eeprom_direct.c, and the API definitions at examples/source/eeprom.c. The APIs are described in [this section](#programming-eeprom-directly).

### Program the EEPROM via Retimer

This example application includes APIs to program the EEPROM via the Aries Retimer. The APIs include 2 modes to program the EEPROM:

1. **Regular write ("Legacy mode"):** This is the regular write process, which writes the entire firmware image to the EEPROM. This write process is slower than the faster Main Micro assisted write (mentioned below). However, it is recommended to use this in error scenarios to try and recover the EEPROM from an invalid firmware. This is available to use across all firmware versions. Setting the "legacyMode" argument in the EEPROM write and verify APIs will enable legacyMode (or if you are running firmware versions prior to 1.0.48).

2. **Main Micro assisted write:** We take help from the Main Micro to speedup the EEPROM accesses via Aries. We have observed up to a 83% reduction in programming time when compared to the legacy mode. This is available from firmware version 1.0.48 (the speed up in the EEPROM verification is available from firmware version 1.0.50).

You can find this example in examples/eeprom_test.c and the API definitions in examples/source/eeprom.c and source/aries_api.c. Based on the current firmware version on the Retimer, we will pick the appropriate programming mode. The APIs are described in [this section](#updating-the-fw-on-aries).

## Monitoring Link Stats

This example application includes link configurations, checking link health, printing link stats and logs from the micros. Once the link is configured and up, the link stats and logs are printed if the link is not in its expected state. The link is considered to be in an unexpected state if any of the following conditions are true:

1. Link lane temperature reading is higher than user specified threshold
2. Link is not in forwarding state
3. Minimum FoM value across all lanes in link is below user specified threshold

The link stats and logs are generated in a folder titled link_logs. This folder would reside at the same level as the link_example executable. Both the folder name and location can be updated (see examples/source/links.c). The link stats are generated in form of a Python dictionary, and you can run print_link_state.py (python post-processing script) to display the stats in a more readable and tabular form. The link logs are also displayed as a python dictionary with log IDs and variables, but you must run print_link_logs.py (python post-processing script) to convert the log ID into a meaningful string. The post-processing scripts are described in [this section](#post-processing-scripts-for-link-statistics-and-logging).

You can find this example in examples/link_example.c and the API definitions in examples/source/links.c and source/aries_api.c.
