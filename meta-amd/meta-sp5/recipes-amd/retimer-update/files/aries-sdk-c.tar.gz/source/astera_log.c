/*
 * Copyright 2020 Astera Labs, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. Thsi file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/*
 * @file aries_log.h
 * @brief Logging module for Aries.
 */

#include "../include/astera_log.h"

#ifdef __cplusplus
extern "C" {
#endif

static struct {
    void *udata;
    log_LockFn lock;
    FILE *fp;
    int level;
    int quiet;
    bool trace_en;
} AriesLogger;

static const char *level_names[] = {
        "TRACE",
        "DEBUG",
        "INFO",
        "WARN",
        "ERROR",
        "FATAL"
};

#ifdef LOG_USE_COLOR
static const char *level_colors[] = {
        "\x1b[94m",
        "\x1b[36m",
        "\x1b[32m",
        "\x1b[33m",
        "\x1b[31m",
        "\x1b[35m"
};
#endif

static void lock(void)
{
    if (AriesLogger.lock)
    {
        AriesLogger.lock(AriesLogger.udata, 1);
    }
}

static void unlock(void)
{
    if (AriesLogger.lock)
    {
        AriesLogger.lock(AriesLogger.udata, 0);
    }
}

void al_log_set_udata(void *udata)
{
    AriesLogger.udata = udata;
}

void al_log_set_lock(log_LockFn fn)
{
    AriesLogger.lock = fn;
}

void al_log_set_fp(FILE *fp)
{
    AriesLogger.fp = fp;
}

void al_log_set_level(int level)
{
    AriesLogger.level = level;
    if (level == 0)
    {
        AriesLogger.trace_en = true;
    }
}

void al_log_set_quiet(int enable)
{
    AriesLogger.quiet = enable ? 1 : 0;
}

void al_log_log(int level, const char *file, int line, const char *fmt, ...)
{
    if (level == 0 && !(AriesLogger.trace_en))
    {
        return;
    }
    else if (level < AriesLogger.level)
    {
        return;
    }

    /* Acquire lock */
    lock();

    /* Get current time */
    time_t t = time(NULL);
    struct tm *lt = localtime(&t);

    /* Log to stderr */
    if (!AriesLogger.quiet)
    {
        va_list args;
        char buf[16];
        buf[strftime(buf, sizeof(buf), "%H:%M:%S", lt)] = '\0';
#ifdef LOG_USE_COLOR
        fprintf(
          stderr, "%s %s%-5s\x1b[0m \x1b[90m%s:%d:\x1b[0m ",
          buf, level_colors[level], level_names[level], file, line);
#else
        fprintf(stderr, "%s %-5s %s:%d: ", buf, level_names[level], file, line);
#endif
        va_start(args, fmt);
        vfprintf(stderr, fmt, args);
        va_end(args);
        fprintf(stderr, "\n");
        fflush(stderr);
    }

  /* Log to file */
    if (AriesLogger.fp)
    {
        va_list args;
        char buf[32];
        buf[strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", lt)] = '\0';
        fprintf(AriesLogger.fp, "%s %-5s %s:%d: ", buf, level_names[level], file, line);
        va_start(args, fmt);
        vfprintf(AriesLogger.fp, fmt, args);
        va_end(args);
        fprintf(AriesLogger.fp, "\n");
        fflush(AriesLogger.fp);
    }

    /* Release lock */
    unlock();
}

#ifdef __cplusplus
}
#endif
